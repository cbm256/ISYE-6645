In the zip files please find the following documents:

1) Spreadsheet of Assumption - contains 4 sheets:
	a) Practice Tuning Exponential IRA - scratchwork for simulating decreasing sales
	b) Tanh Tuning - scratchwork for simulating popularity ranking
	c) Actual Book Sales - Real book sales data shared by company partner, used as basis for understanding demand.
	d) Popularity Rankings - Real book popularity rankings graph over time shared by company partner, used as basis for understanding popularity ranking.

2) SimpleExploratoryModel - this was the first model that I made. Used naive assumptions detailed in writeup. Generate 	report to receive, Days-to-Flip time. 

3) NuancedModel - thiss was the final model I made after refine the demand process for books. Generate report to receive, Days-to-Flip time. 