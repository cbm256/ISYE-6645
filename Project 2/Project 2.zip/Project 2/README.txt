File descriptions are as follows:

1) Project 2 Writeup - another copy for some reason.
2) Simple1 - Arena model simulating only initial 1 book interactions.
3) MultiBooks - Arena model simulating a series of books. 
4) simpleLn - R code used to regress click and cost data found in Sales&Marketing.xlsx
5) Sales&Marketing - spreadsheet with the sales and marketing data from the 1 book that the company has published so far. Used as a basis for many assumptions. 
6) Spreadsheet of Assumptions - my sandbox for tuning a desired exponential shape. 